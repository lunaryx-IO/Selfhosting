# Begleitmaterial zu Webhosting · Band 1

Materialfassung 2026.10.12-r3 · 12. Oktober 2026

Beginnen Sie mit der [Materialübersicht Ihres Bandes](band-1/README.md). Die Vorlagen, Beispiele und Übungen für diesen Band sind vollständig enthalten. Dazu kommen die gemeinsamen Testberichte und die Aufgaben für das Probelesen.

[Prüfberichte](pruefungen/README.md) · [Testleser-Leitfaden](mitmachen/README.md) · [Rückmeldung](RUECKMELDUNG.md)

Hinweise zum jeweils anderen Band führen bei Bedarf zum öffentlichen Repository. Ihre eigenen ausgefüllten Unterlagen bleiben lokal.
