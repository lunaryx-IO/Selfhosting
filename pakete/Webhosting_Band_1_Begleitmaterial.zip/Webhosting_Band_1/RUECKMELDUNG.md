# Eine hilfreiche Rückmeldung geben

Wenn eine Erklärung unklar bleibt, interessiert uns besonders, was Sie an dieser Stelle erwartet haben. Sie müssen dafür keine Fehlerursache kennen und keinen Verbesserungsvorschlag ausarbeiten.

Nennen Sie bitte **Band, Kapitel, Abschnitt und Materialfassung**. Beschreiben Sie anschließend knapp Ihren nächsten beabsichtigten Schritt, das tatsächlich beobachtete Ergebnis und die Stelle, an der Ihnen eine Erklärung gefehlt hat. Für längere Durchgänge können Sie das [Rückmeldeblatt](mitmachen/RUECKMELDEBLATT.md) verwenden.

Eine öffentliche Meldung ist über die [GitHub-Issues](https://github.com/lunaryx-IO/Selfhosting/issues) möglich; dafür benötigen Sie ein GitHub-Konto. Beim vereinbarten Probelesen können Sie Ihre Notizen stattdessen über den mit dem Autor abgesprochenen Weg zurückgeben.

**Vor dem Teilen:** Entfernen Sie Passwörter, Schlüssel, Tokens, Wiederherstellungscodes, geheime Melde-URLs sowie persönliche oder geschäftliche Daten. Bei Bildschirmfotos achten Sie auch auf sichtbare Browser-Tabs und Kontonamen. Für eine Buchrückmeldung reichen meist erfundene Namen und der gekürzte relevante Ausschnitt.

Vermutete Sicherheitsprobleme oder versehentlich enthaltene Geheimnisse bitte nicht als öffentliche Ausgabe anhängen. Geben Sie zunächst nur an, welcher Bereich betroffen ist, und stimmen Sie einen vertraulichen Übermittlungsweg ab.
